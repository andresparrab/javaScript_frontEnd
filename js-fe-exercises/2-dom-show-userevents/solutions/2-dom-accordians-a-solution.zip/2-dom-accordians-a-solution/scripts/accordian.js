// you should use a loop ...

const element = document.getElementsByClassName("accordian-container");

for (let i = 0; i < element.length; i++) {
    element[i].addEventListener("click", function () {
        this.classList.toggle("active");
    })
}