# A dynamic menu

A smal simple menu, added dynamically with JavaScript
